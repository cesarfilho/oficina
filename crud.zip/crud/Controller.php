<?php
function __autoload($className){
	include_once("models/$className.php");	
}

$users=new User("localhost","root","","ipamp_sys");
$clientes=new Cliente("localhost","root","","ipamp_sys");
$veiculos=new Veiculo("localhost","root","","ipamp_sys");

if(!isset($_POST['action']) &&  !isset($_GET['action'])) {
	print json_encode(0);
	return;
}

switch($_POST['action']) {

////////////////////// Cliente //////////////////////////
	case 'get_clientes':
		print $clientes->getClientes();
	break;

	case 'get_cliente':
		$cliente = new stdClass;
		$cliente = json_decode($_POST['cliente']);
		print $clientes->getCliente($cliente);	
	break;
	
	case 'add_cliente':
		$cliente = new stdClass;
		$cliente = json_decode($_POST['cliente']);
		print $clientes->add($cliente);		
	break;
	
	case 'delete_cliente':
		$cliente = new stdClass;
		$cliente = json_decode($_POST['cliente']);
		print $clientes->delete($cliente);		
	break;
	
	case 'update_cliente_data':
		$cliente = new stdClass;
		$cliente = json_decode($_POST['cliente']);
		print $clientes->updateValores($cliente);				
	break;	

////////////////////// Veiculo //////////////////////////
	case 'get_veiculos':
		print $veiculos->getVeiculos();
	break;

	case 'get_veiculo':
		$veiculo = new stdClass;
		$veiculo = json_decode($_POST['veiculo']);
		print $veiculos->getCliente($veiculo);	
	break;

	case 'get_busca_veiculo':
		$veiculo = new stdClass;
		$veiculo = json_decode($_POST['veiculo']);
		print $veiculos->getCliente($veiculo);	
	break;
	
	case 'add_veiculo':
		$veiculo = new stdClass;
		$veiculo = json_decode($_POST['veiculo']);
		print $veiculos->add($veiculo);		
	break;
	
	case 'delete_veiculo':
		$veiculo = new stdClass;
		$veiculo = json_decode($_POST['veiculo']);
		print $veiculos->delete($veiculo);		
	break;
	
	case 'update_veiculo_data':
		$veiculo = new stdClass;
		$veiculo = json_decode($_POST['veiculo']);
		print $veiculos->updateValores($veiculo);				
	break;		
}

exit();