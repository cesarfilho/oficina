*This is a examle to create a applition for CRUD by using MVC design�pattern,��PDO extension, Jquery and Twitter Bootstrap.
uisng JSON as�data-interchange format for HTTP request and response.*