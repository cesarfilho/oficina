<?php

class Orcamento {
	
	private $dbh;

	private $tabelaOrcamento = 'mod_orcamento';
	
	public function __construct($host,$user,$pass,$db)	{		
		$this->dbh = new PDO("mysql:host=".$host.";dbname=".$db,$user,$pass);		
	}

	public function getOrcamentos(){	
		$sth = $this->dbh->prepare("SELECT * FROM ".$this->tabelaOrcamento);
		$sth->execute();
		return json_encode($sth->fetchAll());
	}

	public function getOrcamento($orcamento){				
		$sth = $this->dbh->prepare("SELECT * FROM ".$this->tabelaOrcamento." WHERE id=".$orcamento);
		$sth->execute();
		return json_encode($sth->fetchAll());
	}


	public function add($orcamento){		
		$valida = $this->ValidaValores($orcamento);
		if ($valida == 0){	
		$sth = $this->dbh->prepare("INSERT INTO ".$this->tabelaOrcamento."(
			marca,
			modelo,
			ano,
			cor,
			placa,
			km
			) VALUES (?,?,?,?,?,?)");
			$sth->execute(array(
								 $orcamento->marca,
								 $orcamento->modelo, 
								 $orcamento->ano,
								 $orcamento->cor,							 
								 $orcamento->placa,							 
								 $orcamento->km
								 ));		
			return json_encode($this->dbh->lastInsertId());
		}else{
			return json_encode($valida);
		}
	}
	
	public function delete($orcamento){				
		$sth = $this->dbh->prepare("DELETE FROM ".$this->tabelaOrcamento." WHERE id=?");
		$sth->execute(array($orcamento->id));
		return json_encode(1);
	}
	
	public function updateValue($orcamento){	
		$sth = $this->dbh->prepare("UPDATE ".$this->tabelaOrcamento." SET ". $orcamento->field ."=? WHERE id=?");
		$sth->execute(array($orcamento->newvalue, $orcamento->id));				
		return json_encode(1);	
	}

	public function updateValores($orcamento){	
		$campos = null;
		$valores = array();		
		$idtemp = $orcamento->id;
		unset($orcamento->id);
		foreach ($orcamento as $campo => $valor) {
			if ($campos != null) {$campos .= ',';}
				$campos .= $campo."=?" ;
			$valores[$campo] = $valor ;			
		}
		$sth = $this->dbh->prepare("UPDATE ".$this->tabelaOrcamento." SET ". $campos ." WHERE id=".$idtemp);
		$sth->execute(array_values($valores));
		return json_encode(1);	
	}

    public function FormataDataToDb($data){
        $saida = explode('/',$data);
        if (count($saida) <2){
        	return $erro ='data2 formato inválido';
        }
        if (checkdate($saida[1],$saida[2],$saida[0]) == 1){
        	$saida = "$saida[2]-$saida[1]-$saida[0]";        	
        	return $saida;
        }
        else
        	return $erro = 'data iválida';

    }	

    public function ValidaValores($orcamento){

    	if ((trim($orcamento->marca)) == null){
    		$erro = 'marca';
			$msg_erro = 'Marca vazia ou inválida!';    		
    	}
    	if ((trim($orcamento->modelo)) == null){
    		$erro = 'modelo';
			$msg_erro = 'Modelo vazio!';    		
    	}		
    	if ((trim($orcamento->ano)) == null){
    		$erro = 'ano';
    		$msg_erro = 'Ano vazio ou inválido!';
    	}
    	if ((trim($orcamento->cor)) == null){
    		$erro = 'cor';
    		$msg_erro = 'Cor vazio ou inválido!';
    	}
    	if ((trim($orcamento->placa)) == null){
    		$erro = 'placa';
    		$msg_erro = 'Placa vazio ou inválido!';
    	}
    	if ((trim($orcamento->km)) == null){
    		$erro = 'km';
    		$msg_erro = 'KM vazio ou inválido!';
    	}
    	if (isset($erro)){
    		$saida['campo'] = $erro;
    		$saida['msg_erro'] = $msg_erro;
    		return $saida;
    	}else{
    		return 0;
    	}
    }
}
?>